from django.db import models

# Create your models here.

class Admin_Details(models.Model):
    Username = models.CharField(max_length=100)
    Password = models.CharField(max_length=100)
    
    class Meta:
        db_table = 'Admin_Details'





class Product_Details(models.Model):
    ProductId = models.IntegerField(default=None)
    ProductName = models.CharField(max_length=20,default=None)
    ProductDescription  = models.CharField(max_length=100,default=None)
    MRP = models.IntegerField(default=None)
    Discount = models.IntegerField(default=None)
    DiscountPercentage = models.IntegerField(default=0)
    FinalPrice = models.IntegerField(default=None)
    OfferDate = models.DateField(default="2021-12-19")


        
    class Meta:
        db_table = 'Product_Details'



class Customer_Details(models.Model):
    First_name = models.CharField(max_length=50)
    Last_name = models.CharField(max_length=50)
    Dob = models.CharField(max_length=50,default=None)
    Gender = models.CharField(max_length=10)
    Phone = models.IntegerField(default=None)
    Email = models.EmailField()
    Password = models.CharField(max_length=100)
    Address = models.CharField(max_length=100)
    City = models.CharField(max_length=100)
    State = models.CharField(max_length=100)
    Username = models.IntegerField(default=None)

    
    class Meta:
        db_table = 'Customer_Details'



class Staff_Details(models.Model):
    Username = models.CharField(max_length=100)
    Password = models.CharField(max_length=100)
    
    class Meta:
        db_table = 'Staff_Details' 
               

class Cart(models.Model):

    ProductId = models.IntegerField(default=None)
    ProductName = models.CharField(max_length=20,default=None)
    MRP = models.IntegerField(default=None)
    Discount = models.IntegerField(default=None)
    FinalPrice = models.IntegerField(default=None)
    TotalPrice = models.IntegerField(default=None)
    Username = models.IntegerField(default=None)
    
    
    class Meta:
        db_table = 'Cart' 


class Order(models.Model):

    ProductId = models.IntegerField(default=None)
    OrderId = models.IntegerField(default=None)
    OrderDate = models.DateField(default="2021-12-19")
    Discount = models.IntegerField(default=0)
    MRP = models.IntegerField(default=0)
    ProductName = models.CharField(max_length=20,default=None)
    FinalPrice = models.IntegerField(default=None)
    Username = models.IntegerField(default=None)
    
    
    class Meta:
        db_table = 'Order'         
               

