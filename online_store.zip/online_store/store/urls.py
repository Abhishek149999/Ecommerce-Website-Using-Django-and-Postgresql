from django.urls import path
from . import views

urlpatterns = [
	path('', views.home, name='home'),
	path('Product/', views.Product, name='Product'),
	path('Product2/', views.Product2, name='Product2'),
	path('Customer_login/', views.Customer_login, name='Customer_login'),
	path('Admin_login/', views.Admin_login, name='Admin_login'),
	path('Staff_login/', views.Staff_login, name='Staff_login'),
	path('Register/', views.Register, name='Register'),
	path('logout/', views.logout, name='logout'),
	path('AddProduct/', views.AddProduct, name='AddProduct'),
	path('ViewProduct/', views.ViewProduct, name='ViewProduct'),
	path('DeleteProduct/<int:id>',views.DeleteProduct,name='DeleteProduct'),
	path('ProductDetails/', views.ProductDetails, name='ProductDetails'),
	path('UpdateProduct/', views.UpdateProduct, name='UpdateProduct'),
	path('Orders/<int:id>', views.Orders, name='Orders'),
	path('ViewCart/<int:id>', views.ViewCart, name='ViewCart'),
	path('Add_Cart/<int:id>,<int:ids>', views.Add_Cart, name='Add_Cart'),
	path('ConfirmOrder/<int:id>', views.ConfirmOrder, name='ConfirmOrder'),












]