from django.shortcuts import render,redirect
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.contrib import messages
from .models import Admin_Details,Product_Details,Customer_Details,Staff_Details,Cart,Order
import random
from django.contrib.sessions.models import Session
from datetime import date
from datetime import datetime
from datetime import timedelta

# Create your views here.
from django.http import HttpResponse



def home(request):
    if request.method == 'POST':
        pass
    else:
        return render(request, 'home.html', {})


def Product(request):
    Product= Product_Details.objects.all()[0:6]
    return render(request, 'Product.html', {"Product" : Product})
    

def Product2(request):
    Product= Product_Details.objects.all()[6:12]
    return render(request, 'Product2.html', {"Product" : Product})


def Admin_login(request):
    if request.method == 'POST':
        Username = request.POST['Username']
        password = request.POST['password']
        
        if Admin_Details.objects.filter(Username=Username, Password=password).exists():
                user = Admin_Details.objects.get(Username=Username, Password=password)
                request.session['type_id'] = 'Admin'
                request.session['username'] = Username
                request.session['login'] = 'Yes'
                return redirect('/')
        else:
            messages.info(request,'Invalid Credentials')
            return redirect('/Admin_login/')
    else:
        return render(request, 'Admin_login.html', {})


def Staff_login(request):
    if request.method == 'POST':
        Username = request.POST['Username']
        password = request.POST['password']
        
        if Staff_Details.objects.filter(Username=Username, Password=password).exists():
                user = Staff_Details.objects.get(Username=Username, Password=password)
                request.session['type_id'] = 'Staff'
                request.session['username'] = Username
                request.session['login'] = 'Yes'
                return redirect('/')
        else:
            messages.info(request,'Invalid Credentials')
            return redirect('/Staff_login/')
    else:
        return render(request, 'Staff_login.html', {})


def Customer_login(request):
    if request.method == 'POST':
        Username = request.POST['Username']
        password = request.POST['password']
        
        if Customer_Details.objects.filter(Username=Username, Password=password).exists():
                user = Customer_Details.objects.get(Username=Username, Password=password)
                request.session['type_id'] = 'Customer'
                request.session['username'] = Username
                request.session['login'] = 'Yes'
                return redirect('/')
        else:
            messages.info(request,'Invalid Credentials')
            return redirect('/Customer_login/')
    else:
        return render(request, 'Customer_login.html', {})        


def Register(request):
    if request.method == 'POST':           
        First_name = request.POST['First_name']
        Last_name = request.POST['Last_name']
        Username = request.POST['Username']
        Dob = request.POST['Dob']
        Gender = request.POST['Gender'] 
        Phone = request.POST['Phone']
        Email = request.POST['Email']
        Password = request.POST['Password']
        final_address = request.POST['Address1']
        City = request.POST['City']
        State = request.POST['State']
        register = Customer_Details( First_name=First_name,Last_name=Last_name, 
            Dob=Dob, Gender=Gender ,Phone= Phone,Email= Email,
            Username= Username,Password=Password,Address=final_address,City=City,State=State)
        register.save()
        
        
        if request.session.get('type_id', None):
            messages.info(request,'Customer Registered Successfully')
            return redirect('/Register/')
        else:
            messages.info(request,'Customer Registered Successfully')
            return redirect('/Customer_login/')
    else:
        return render(request, 'Register.html', {})


def logout(request):
    Session.objects.all().delete()
    messages.info(request,'Account logout')
    return redirect('/')


def AddProduct(request):
    if request.method == 'POST':
        ProductId = request.POST['ProductId']
        ProductName = request.POST['ProductName']
        ProductDescription = request.POST['ProductDescription']
        MRP = request.POST['MRP']
        FinalPrice = request.POST['FinalPrice']
        price=int(MRP)
        f_price=int(FinalPrice)
        addproduct = Product_Details( ProductId=ProductId, ProductName=ProductName, ProductDescription=ProductDescription, 
            MRP=MRP, Discount=price-f_price , FinalPrice=FinalPrice, )
        addproduct.save()
        messages.info(request,'Product Added Successfully')
        return redirect('/AddProduct/')
        
        pass
    else:
        return render(request, 'AddProduct.html', {})  


def ViewProduct(request):
    if request.method == 'POST':
        pass
    else:
        Product = Product_Details.objects.all()
        return render(request, 'ViewProduct.html', {'Product':Product})


def ViewCart(request,):
    if request.method == 'POST':
        pass
    else:
        Product = Product_Details.objects.all()
        return render(request, 'ViewCart.html', {'Product':Product})


def DeleteProduct(request,id):
    Product_Details.objects.filter(ProductId=id).delete()
    messages.info(request,'Product Deleted')
    return redirect('/ViewProduct/',{})  


def ProductDetails(request):
    if request.method == 'POST':
        pass
    else:
        Product = Product_Details.objects.all()
        return render(request, 'ProductDetails.html', {'Product':Product})          


def UpdateProduct(request):
    if request.method == 'POST':
        ProductId = request.POST['ProductId']
        ProductName = request.POST['ProductName']
        ProductDescription = request.POST['ProductDescription']
        MRP = request.POST['MRP']
        #Discount = request.POST['Discount']
        OfferDate = request.POST['OfferDate']
        DiscountPercentage = request.POST['DiscountPercentage']
        price=int(MRP)
        percent=int(DiscountPercentage)
        Discount= price*(percent/100)
        discoun=int(Discount)
        FinalPrice = price-discoun
        Product_Details.objects.filter(ProductId=ProductId).update(ProductId=ProductId,
            ProductName=ProductName, ProductDescription=ProductDescription, MRP=MRP, 
            Discount=Discount ,OfferDate= OfferDate,DiscountPercentage= DiscountPercentage,
            FinalPrice= FinalPrice)
        messages.info(request,'Product Updated Successfully')   
        return redirect('/ProductDetails/')

    else:
        return redirect('/ProductDetails/')    


def Add_Cart(request,id,ids):
    prod=Product_Details.objects.all().filter(ProductId=id)
    name=prod[0].ProductName
    mrp=prod[0].MRP
    disc=prod[0].Discount
    date=prod[0].OfferDate
    fprice=prod[0].FinalPrice

    a=date.today()
    if(date == a):
        Discount=disc
        FinalPrice=fprice
    else:
        Discount=0
        FinalPrice=mrp
    add_cart = Cart(ProductId=id, ProductName=name,
        Discount=Discount,MRP=mrp,FinalPrice=FinalPrice,Username=ids)
    add_cart.save()
    messages.info(request,'Product Added Successfully in Your cart')
    Product= Product_Details.objects.all()

    return render(request, 'Product.html',{"Product" : Product})

              
def ViewCart(request,id):
    if request.method == 'POST':
        pass
    else:
        Cart_ = Cart.objects.all().filter(Username=id)
        return render(request, 'ViewCart.html', {'Cart':Cart_})


def ConfirmOrder(request,id):
    a=date.today()
    i=Cart.objects.all().filter(Username=id).count()
    Cart_ = Cart.objects.all().filter(Username=id)
    while(i!=0):
        i=i-1
        prod=Cart_[i].ProductId

        order_id=random.randint(1,100000)

        name=Cart_[i].ProductName
        prod=Cart_[i].ProductId
        mrp=Cart_[i].MRP
        discount=Cart_[i].Discount
        fprice=Cart_[i].FinalPrice
        add_order=Order(ProductId=prod,OrderId=order_id,OrderDate=a,ProductName=name,FinalPrice=fprice,
            Username=id,Discount=discount,MRP=mrp)
        add_order.save()
        Cart.objects.filter(Username=id,ProductId=prod).delete()
    order = Order.objects.all().filter(Username=id)
    return render(request, 'Orders.html',{'Order':order})        


def Orders(request,id):
    order = Order.objects.all().filter(Username=id)
    return render(request, 'Orders.html', {'Order':order})


    